export interface IListState {
    list: IListItem 
}

export interface IListItem {
    
}