import { OrthoFrustum, PerspectiveFrustum } from "../../plugins/main";
export declare type StdView = {
    name: string;
    position: [number, number, number];
    dir: [number, number, number];
    up: [number, number, number];
    perspective: PerspectiveFrustum;
    ortho: OrthoFrustum;
};
export declare const orthoToPerspective: (left: number, right: number, top: number, bottom: number, near: number, far: number) => {
    fov: number;
    aspect: number;
    near: number;
    far: number;
};
export declare const perspectiveToOrtho: (fov: number, aspect: number, near: number, far: number) => {
    left: number;
    right: number;
    top: number;
    bottom: number;
    near: number;
    far: number;
};
