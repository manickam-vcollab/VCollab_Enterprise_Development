import * as glmatrix from "gl-matrix";
import { AppState } from '../AppState';
import { EventDispatcher } from '../EventDispatcher';
import vctViewer from "../../plugins/main";
declare class GUIState {
    planeOptions: Map<PlaneId, PlaneGUIState>;
    constructor();
}
export declare enum SelectionMode {
    NONE = 0,
    THREE_PT = 1,
    FACE = 2
}
declare class PlaneGUIState {
    isPlaneEnabled: boolean;
    isPlaneVisible: boolean;
    sliderMinMax: [number, number];
    primarySliderValue: number;
    rotSliderUValue: number;
    rotSliderVValue: number;
    rotSliderNValue: number;
    delta: number;
    deltaRotU: number;
    deltaRotV: number;
    deltaRotN: number;
    transform: glmatrix.mat4;
    initTransform: glmatrix.mat4;
    constructor();
}
export declare type PlaneId = number | string;
export declare type Color = [number, number, number, number];
declare class Section {
    private viewerId;
    private renderApp;
    private appState;
    private activePlaneId;
    private externalEvents;
    private externalEventDispatcher;
    private eventDispatcher;
    private bbox;
    private guiState;
    private selectedPts;
    constructor(viewerId: any, _renderApp: vctViewer, appState: AppState, eventDispatcher: EventDispatcher);
    registerEvents(): void;
    handle3ptSelect(probeData: any): void;
    handleFaceSelect(probeData: any): void;
    handleSelection(e: any): void;
    handleOnModelLoad(e: any): void;
    getSectionGUIData(): any;
    setSectionGUIData(guiState: GUIState): void;
    addSectionPlane(planeId: PlaneId, transform: glmatrix.mat4, color: Color): void;
    deleteSectionPlane(planeId: PlaneId): void;
    setSectionPlaneEquation(planeId: PlaneId, transform: glmatrix.mat4, initTransform?: glmatrix.mat4): void;
    getSectionPlaneEquation(planeId: PlaneId): {
        transform: glmatrix.mat4;
        initTransform: glmatrix.mat4;
    };
    setActive(planeId: PlaneId): void;
    setSelection(mode: SelectionMode): void;
    setPlaneState(planeId: PlaneId, params: any): void;
    invert(planeId: PlaneId): void;
    planeFrom3pts(planeId: PlaneId, p1: glmatrix.vec3, p2: glmatrix.vec3, p3: glmatrix.vec3, transform: glmatrix.mat4): void;
    translatePlane(delta: number, deltaSlice: number, planeId: number): void;
    rotatePlane(deltaU: number, deltaV: number, deltaN: number, planeId: number): void;
    setBounds(planeId: PlaneId): void;
}
export { Section };
