import { EventObj } from "./Events";
declare class EventDispatcher {
    private _listeners;
    constructor();
    addEventListener(type: any, listener: any): void;
    hasEventListener(type: any, listener: any): boolean;
    removeEventListener(type: any, listener: any): void;
    removeAllEventListener(): void;
    dispatchEvent(event: EventObj): void;
}
export { EventDispatcher };
