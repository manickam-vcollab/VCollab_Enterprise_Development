import { ModelTreeBuilder, ModelTree, TreeNode } from "./Tree";
interface IModelInfo {
    name: string;
}
export { IModelInfo, ModelTreeBuilder, ModelTree, TreeNode };
