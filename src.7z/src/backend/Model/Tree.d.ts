interface TreeNode {
    id: string;
    pid: string | null;
    children: string[];
    customData: any;
    title: string;
    attributes: any;
}
declare class ModelTree {
    models: Map<string, TreeNode>;
    rootNodeIds: string[];
    constructor(treeMap: Map<string, TreeNode>, modelIds: string[]);
    getVisibleNodeIds(): string[];
    getInvisibleNodeIds(): string[];
    getPartNodeFromNodeIds(nodeIds: string[]): TreeNode[];
    getAllPartNodes(): TreeNode[];
    getRepresentationsFromParts(nodes: TreeNode[]): any[];
    getRenderNodeIdsFromNodeIds(nodeIds: string[]): any[];
    getPartIdsFromRenderNodeIds(renderIds: number[]): string[];
    setVisibility(nodes: TreeNode[], toShow: boolean): void;
}
declare class ModelTreeBuilder {
    private mcax;
    private tree;
    constructor(_mcax: any);
    build(): ModelTree;
    private processModels;
    private buildComponentsHierachy;
    private buildChildHierachy;
    private processGeometries;
    private processRepresentation;
    private filter;
}
export { ModelTreeBuilder, ModelTree, TreeNode };
