export interface IPartDisplayState {
    displayId: string;
    hiddenlineEnabled: boolean;
    isHighlighted: boolean;
    useTexture: boolean;
    transparency: number;
    visibility: boolean;
}
export interface IDisplayMode {
    id: string | number;
    displayName: string;
    displayOrder: number;
    isDataAvailable: boolean;
    downloadMetricType: string;
    downloadMetricValue: number;
}
