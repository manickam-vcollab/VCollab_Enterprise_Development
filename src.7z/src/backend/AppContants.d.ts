export declare const orientation: {
    VERTICAL: number;
    HORIZONTAL: number;
};
export declare const paletteType: {
    CONTINUOUS: number;
    DISCRETE: number;
};
export declare const valueType: {
    CONTINUOUS: number;
    DISCRETE: number;
};
export declare const valuePlacement: {
    EDGE: number;
    MIDDLE: number;
};
export declare const ticsPosition: {
    NONE: number;
    INSIDE: number;
    OUTSIDE: number;
    ACROSS: number;
};
export declare const colorValueMode: {
    BOUNDED: number;
    EXTENDED: number;
};
export declare const colorMap: {
    PRESET1: number[][];
    COLORS_2: number[][];
};
export declare enum InteractionMode {
    DEFAULT = 0,
    CONTINUOUS_PROBE = 1,
    LABEL2D = 2,
    LABEL3D_POINT = 3,
    LABEL3D_FACE = 4,
    LABEL_MEASUREMENT_POINT_TO_POINT = 5,
    LABEL_MEASUREMENT_3PT_ARC = 6,
    SECTION_3PT = 7,
    SECTION_FACE = 8,
    PICK_AND_MOVE = 9
}
export declare const displayModes: {
    [id: string]: {
        ID: string;
        DISPLAYNAME: string;
        DISPLAYORDER: number;
    };
};
export declare const downloadMetricTypes: {
    NONE: string;
    SIZE: string;
    TIME: string;
};
export declare enum BackgroundType {
    GRADIENT = 0,
    IMAGE = 1
}
