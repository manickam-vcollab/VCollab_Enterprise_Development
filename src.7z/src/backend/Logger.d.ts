declare enum statusIconType {
    NONE = 0,
    ERROR = 1,
    WARN = 2,
    INFO = 3,
    SUCCESS = 4
}
declare class Logger {
    static externalLogger: any;
    static setExternalLogger(externalLogger: any): void;
    static setStatusBar(text: string, iconType?: statusIconType): void;
    static clearStatusBar(): void;
}
export { Logger, statusIconType };
