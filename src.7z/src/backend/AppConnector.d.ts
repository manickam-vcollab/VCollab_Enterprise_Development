declare class AppConnector {
    private connector;
    private eventDispacther;
    private baseUrl;
    constructor(viewerId: string, _eventDispacther: any);
    getArrayBuffer(downloadId: any, url: any): Promise<unknown>;
    getJsonData(url: any): Promise<unknown>;
    getNetworkMetrics(): string;
    getModel(API: any, caxFilePath: any, viewerID: any): Promise<unknown>;
    checkTaskStatus(taskURL: any, taskId: any, viewerID: any, statusMessage: any, onCompleteCallbackFn: any): void;
    isJson(item: any): boolean;
}
export { AppConnector };
