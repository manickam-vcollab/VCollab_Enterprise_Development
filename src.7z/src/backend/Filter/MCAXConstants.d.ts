export declare enum RepresentationType {
    BBOX = 24,
    MESH = 132,
    WIREFRAME = 136,
    POINTS = 384,
    HIGHLIGHT = 143345245
}
