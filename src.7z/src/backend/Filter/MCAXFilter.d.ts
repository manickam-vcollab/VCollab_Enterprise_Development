declare class MCAXFilter {
    private renderApp;
    private mcax;
    constructor(renderer: any, mcax: any);
    getRenderableGeometries(): any[];
    getRecursiveItems(indexList: any[], items: any[]): any[];
    getVisibleGeometries(representationsId: any): any[];
    getRepresentationType(id: any): string;
}
export { MCAXFilter };
