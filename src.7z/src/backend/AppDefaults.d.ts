export declare const Default: {
    LEGEND_ORIENTATION: number;
    LEGEND_PALETTE_TYPE: number;
    LEGEND_VALUE_TYPE: number;
    LEGEND_VALUE_PLACEMENT: number;
    LEGEND_TICS_POSITION: number;
    LEGEND_COLOR_VALUE_MODE: number;
    LEGEND_COLOR_MAP: number[][];
};
