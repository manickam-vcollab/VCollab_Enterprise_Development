import vctViewer from "../plugins/main";
declare class URLObject {
    url: any;
    bufferViewOffset: any;
    bufferViewLength: number;
    bufferIndex: any;
    bufferViewIndex: any;
    accessorIndex: any;
    meshIndex: any;
    nodeIndex: any;
    constructor(_url: any);
}
declare class GltfUrlExtractor {
    private glftJSON;
    private renderApp;
    constructor(_glftJSON: any, renderApp: vctViewer);
    getNodeURLs(nodeIndex: number): any[];
    getMeshURLs(nodeIndex: number, meshIndex: any): any[];
    getAccessorURLs(accessorIndex: any): URLObject;
    getBufferViewURLs(bufferViewIndex: any): URLObject;
    getBufferURLs(bufferIndex: any): any;
}
export { GltfUrlExtractor };
