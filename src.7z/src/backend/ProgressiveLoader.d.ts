import { AppConnector } from './AppConnector.js';
declare class ProgressiveLoader {
    private mcax;
    private renderApp;
    private connector;
    private gltfurlExtractor;
    constructor(_mcax: any, _renderApp: any, _connector: AppConnector);
    showDefaultDisplay(): Promise<void>;
    getRenderableGeometries(): any[];
    getRecursiveItems(indexList: any[], items: any[]): any[];
    loadSelectedRepresentations(downloadId: string, representations: any[]): Promise<unknown>;
    getRepresentationsByLevel(representationList: any[], level: any): any[];
    loadLevelNodes(downloadId: string, representationList: any[], currentLevel: any, allselectedLevels: any): Promise<unknown>;
    loadRespresentationNodes(downloadId: string, representationList: any[]): Promise<unknown>;
    splitandUpdateBuffer(URLobj: any, arrayBuffer: any[]): void;
    loadLevelNodes_working(downloadId: string, representationList: any[]): void;
}
declare type ChunkData = {
    offset: number;
    len: number;
};
declare class ManagedURLDownloader {
    static downloadSizeLimit: number;
    static cache: Map<string, Map<string, ChunkData[]>>;
    constructor();
    static createURLGroup(groupId: string): void;
    private static isChunkCached;
    static processURLObject(groupId: string, urlObjArray: any[]): any[];
    static deleteURLGroup(groupId: string): void;
    static URLMerger(_url: any, specificUrlObjArray: any[]): any[];
}
export { ProgressiveLoader, ManagedURLDownloader };
