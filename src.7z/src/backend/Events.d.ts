export declare enum viewerEvents {
    VIEWER_CLICK = "VIEWER_CLICK",
    VIEWER_DBL_CLICK = "VIEWER_DBL_CLICK",
    MODEL_DOWNLOAD_STATUS_UPDATE = "MODEL_DOWNLOAD_STATUS_UPDATE",
    MODEL_PART_HIGHLIGHTED = "MODEL_PART_HIGHLIGHTED",
    SECTION_PLANE_SELECTED = "SECTION_PLANE_SELECTED",
    CAMERA_MOVED = "CAMERA_MOVED",
    DOWNLOAD_START = "DOWNLOAD_START",
    DOWNLOAD_PROGRESS = "DOWNLOAD_PROGRESS",
    DOWNLOAD_END = "DOWNLOAD_END",
    INTERACTION_MODE_CHANGED = "INTERACTION_MODE_CHANGED",
    LABEL3D_CREATED = "LABEL3D_CREATED"
}
export declare enum internalEvents {
    NETWORK_CREATE_GROUP = "NETWORK_CREATE_GROUP",
    NETWORK_ADD_PART = "NETWORK_ADD_PART",
    NETWORK_UPDATE_PART = "NETWORK_UPDATE_PART",
    NETWORK_DELETE_GROUP = "NETWORK_DELETE_GROUP"
}
export declare enum globalEvents {
    ERROR = "ERROR",
    INFO = "INFO",
    WARN = "WARN",
    LOG = "LOG"
}
export declare type EventObj = {
    type: viewerEvents | globalEvents | internalEvents;
    viewerID: any;
    data: any;
    target?: any;
};
