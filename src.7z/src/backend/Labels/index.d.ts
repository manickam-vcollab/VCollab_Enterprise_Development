import { AppState } from '../AppState';
import { Viewer } from '../Viewer';
import { Label3DType } from '../../plugins/main';
import { IProbeData } from '../../plugins/Picker';
declare class LabelManager {
    private renderApp;
    private viewer;
    private appState;
    private events;
    private externalEventDispatcher;
    private hitPoints;
    constructor(_renderApp: any, appState: AppState, viewer: Viewer);
    registerEventHandlers(): void;
    handleClick(event: any): void;
    handleProbeLabel(event: any, type: Label3DType): void;
    handleMeasurementP2P(event: any): void;
    handleMeasurementArc(event: any): void;
    add3DLabel(id: string, hitPoint: number[], type: Label3DType, probeData: IProbeData): void;
    delete3DLabel(id: string): boolean;
    get3DLabelCanvasPos(id: string): number[] | null;
}
export { LabelManager };
