export declare const basicType: Readonly<{
    ANALYTICAL: number;
    PRIMITIVES: number;
    CONNECTIONS: number;
    BOUNDING_BOX: number;
    FEATURE_EDGES: number;
    SIMPLIFIED: number;
    FULL_MESH: number;
    MESH_POINTS: number;
}>;
export declare let powof2: (value: number) => number;
export declare const abstractType: Readonly<{
    BBOX: number;
    MESH: number;
    WIREFRAME: number;
    POINT: number;
}>;
