export interface IVariable {
    name: string;
    type: string;
    attributes: any;
}
export interface IVariableType {
    name: string;
    derivedTypeIds: string[];
    defaultDerived: string;
}
export interface IDerivedType {
    name: string;
    generator: string;
}
export interface IStepVariable {
    name: string;
}
export declare type IMissingVariableStep = string;
export interface ISelection {
    variableId: string;
    stepId: string;
    derivedTypeId: string;
}
export interface ICAEResult {
    variables: {
        [id: string]: IVariable;
    };
    variableTypes: {
        [id: string]: IVariableType;
    };
    derivedTypes: {
        [id: string]: IDerivedType;
    };
    stepVariables: {
        [id: string]: IStepVariable;
    };
    missingVariableSteps: {
        [id: string]: IMissingVariableStep[];
    };
    selection: ISelection;
}
