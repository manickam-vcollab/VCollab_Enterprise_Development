import { AppConnector } from '../AppConnector';
import { LegendManager } from '../LegendManager';
import { ICAEResult } from "./types";
import { ModelTree } from '../Model';
declare class CAEResult {
    private mcax;
    private renderApp;
    private connector;
    private legendManager;
    private result;
    private legendID;
    private appliedResultId;
    private appliedStepId;
    private appliedDerivedTypeId;
    constructor(_mcax: any, _renderApp: any, _connector: AppConnector, _legendManager: LegendManager);
    getIsCAEResultAvailable(): boolean;
    private setDefaultDerived;
    private createResult;
    getCAEResult(): ICAEResult;
    getDisplayResult(): ICAEResult;
    getResults(): void;
    getSteps(selectedResultIndex: number): void;
    getDerivedTypes(selectedResultIndex: number): any;
    applyResult(variableId: string, stepId: string, derivedTypeId: string, productTree: ModelTree): Promise<unknown>;
    getLegendData(): any;
}
export { CAEResult };
