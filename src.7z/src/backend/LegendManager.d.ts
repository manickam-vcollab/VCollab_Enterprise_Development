declare class LegendManager {
    private Legends;
    private defaultLegendsID;
    constructor();
    createLegend(): string;
    getLegend(id: any): any;
}
export { LegendManager };
