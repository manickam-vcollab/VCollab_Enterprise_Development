import { InteractionMode } from './AppContants';
export declare class AppState {
    interactionMode: InteractionMode;
    EPSIOLON: number;
    constructor();
}
