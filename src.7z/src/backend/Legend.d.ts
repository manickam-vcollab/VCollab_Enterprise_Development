declare class Legend {
    private id;
    private orientation;
    private paletteType;
    private valueType;
    private valuePlacement;
    private ticsPosition;
    private colorValueMode;
    private colorMap;
    private isUserCustomDefinedValue;
    private userDefinedValues;
    private min;
    private max;
    constructor(id: any);
    setMinMAX(min: any, max: any): void;
    getDisplayData(): {
        colors: any;
        paletteType: any;
        range: any[];
    };
    getNewColorSet(newSize: number, inColorArray: any[]): any[];
    createTexture(colorArray: any[], textureSize: any, isDiscrete: boolean): any[];
    getTextureData(): any[];
    getRange(): any[];
}
export { Legend };
