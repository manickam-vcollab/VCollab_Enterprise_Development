import { EventDispatcher } from "./EventDispatcher";
declare type DownloadID = string;
declare type DownloadItemGroupID = DownloadID;
declare type DownloadItem = {
    id: string;
    loaded: number;
    total: number;
};
declare type Info = {
    title: string;
    notify: boolean;
    totalSize: number;
};
declare class NetworkManager {
    private viewerId;
    private dispatcher;
    private downloads;
    constructor(eventDispatcher: EventDispatcher, viewerId: string);
    register_events(): void;
    createGroup(info: Info): DownloadItemGroupID;
    private handleAddPart;
    private handleUpdataPart;
    addPart(groupId: DownloadItemGroupID, item: DownloadItem): boolean;
    updatePart(groupId: DownloadItemGroupID, partId: string, event: any): boolean;
    deleteGroup(id: DownloadItemGroupID): boolean;
}
export default NetworkManager;
