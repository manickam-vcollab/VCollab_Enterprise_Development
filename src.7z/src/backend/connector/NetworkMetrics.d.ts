import RequestMeter from './RequestMeter.js';
export default class NetworkMetrics {
    static URLMap: Map<any, any>;
    constructor();
    static addURL(url: any): RequestMeter;
    static getRequestObject(url: any): any;
    static getAllMetrics(): string;
}
