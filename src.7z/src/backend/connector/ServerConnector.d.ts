import { EventDispatcher } from '../EventDispatcher.js';
export declare class ServerConnector {
    private connectionType;
    private eventDispatcher;
    private axiosConnector;
    constructor(viewerId: string, connectionType: any, eventDispatcher: EventDispatcher);
    getJsonData(url: any): Promise<unknown>;
    getArrayBuffer(downloadId: any, url: any): Promise<unknown>;
    getNetworkMetrics(): string;
}
