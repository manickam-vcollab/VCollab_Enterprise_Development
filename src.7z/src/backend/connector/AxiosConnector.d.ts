import { EventDispatcher } from '../EventDispatcher.js';
declare class AxiosConnector {
    private eventDispatcher;
    private viewerId;
    constructor(viewerId: string, eventDispatcher: EventDispatcher);
    send(downloadId: any, _url: any, _data: any, _method: any, _reponseType: any): Promise<unknown>;
}
export { AxiosConnector };
