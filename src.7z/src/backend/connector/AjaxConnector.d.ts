declare class AjaxConnector {
    constructor();
    static xhr2(_url: any, _data: any, _callback: any, _method: any, _async: any, responseType: any): {
        Data: {};
        errorMsgCode: string;
    };
    static send(_url: any, _data: any, _method: any, _async: any, _reponseType: any): Promise<unknown>;
}
export { AjaxConnector };
