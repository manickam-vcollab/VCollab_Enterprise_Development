export default class RequestMeter {
    private _url;
    private _requestInitaitedOn;
    private _firstResponseReceivedOn;
    private _finalResponseReceivedOn;
    private _isErrorOccurred;
    private _isSuccess;
    private _loaded;
    private _progessList;
    private _error;
    size: any;
    timeForFirstResponse: any;
    timeForDownload: any;
    constructor(url: any);
    requestInitaited(): void;
    addProgress(event: any): void;
    succeeded(): void;
    errorOccurred(errorString: string): void;
    getTransferSpeed(): {
        maxSpeed: number;
        avgSpeed: number;
        minSpeed: number;
    };
    getProgress(): any;
    getMetrics(): string;
}
