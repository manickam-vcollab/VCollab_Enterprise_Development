export declare const ServerConnectionType: {
    XHR: number;
    AXIOS: number;
};
export declare const serverURLs: {
    getLicense: string;
    releaseLicense: string;
    ping: string;
    is_free: string;
    getCAEResultList: string;
    connect: string;
    disconnect: string;
    taskState: string;
};
export declare const ResponseType: {
    JSON: string;
    BUFFER: string;
};
export declare const errorCode: {
    noerror: string;
    connectionError: string;
    error404: string;
    serverError: string;
    jsonError: string;
    timeoutError: string;
    ajaxError: string;
    unknownError: string;
    noresponseError: string;
    invalidDataError: string;
};
export declare const SecondsToStructuredString: (time: any) => string;
export declare const BytesToStructuredString: (bytes: any) => string;
export declare const SpeedToStructuredString: (speed: any) => string;
