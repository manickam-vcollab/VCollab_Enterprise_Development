import { PointerData } from "../plugins/Controls/MouseControls";
declare class Utility {
    static create_UUID(): string;
    static getURLParameterByName: (URL: string, name: string) => string;
    static getPathFromUrl: (url: string) => string;
    static deepCopy(obj: any): any;
    static downloadDataAsFile(data: any, filename: any, type: any): void;
    static getProbeInputData(event: any): PointerData;
}
export { Utility };
