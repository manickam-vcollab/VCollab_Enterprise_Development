import { makeStyles } from '@material-ui/core/styles';


export default makeStyles((theme) => ({
    sideBarBody :{
    //backgroundColor: 'blue',
    width : '100%',
    height : 'auto',
    //color: 'white',
    textAlign: 'center',
    },
}));