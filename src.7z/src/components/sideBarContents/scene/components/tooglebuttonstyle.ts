
import { makeStyles } from "@material-ui/core";

export default makeStyles((theme)=>({

    toggleContainer:{
        width:'100%',
        height:'50px',
        marginTop:'30px',
        marginLeft:'16px'
    },
    toggleButtons:{
        float:'left',
    }

}))