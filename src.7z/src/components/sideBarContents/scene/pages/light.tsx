export default function Light (){
    return(
        <div>
            Light
        </div>
       
    )
}