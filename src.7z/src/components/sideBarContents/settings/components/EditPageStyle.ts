import {makeStyles} from '@material-ui/styles'

export default makeStyles((theme)=>({

    listItem:{

        padding:'0px'
    },
    
    selectDropDown:{

        fontSize:"12px",
    },
    alignMenuItem:{

        width:'90%',
        marginTop:'5px',
        display:'flex',
        alignItems:'stretch',
        
    }

}));