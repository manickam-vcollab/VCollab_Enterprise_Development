import React from 'react'

function InspireTree() {
  return (
    <div>InspireTree</div>
  )
}

export default InspireTree